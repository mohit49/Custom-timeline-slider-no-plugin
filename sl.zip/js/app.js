$(document).ready(function () {
  let selectors = {
      body: 'body',
      mainContainer: '.conatiner',
      parallaxOne: '.parallax-one',
      parallaxTwo: '.parallax-two',
      parallaxThree: '.parallax-three',
      parallaxFour: '.parallax-four',
    },
    cssClass = {
      stickFullHeader: 'sticky-full-header',
      stickBottomMenu: 'stick-bottom-menu',
    },
    lastScrollTop = 0;
  $header = $('.iwc-header-wrapper');

  var scrollorama = $.scrollorama({ blocks: '.scrollblock' });
  if ($(window).width() > 768) {
    $('.re-pllx-item').each(function (index) {
      scrollorama.animate($(this), {
        delay: $(this).data('delay'),
        duration: $(this).data('duration'),
        property: $(this).data('property'),
        start: $(this).data('start'),
        end: $(this).data('end'),
      });
    });

    scrollorama.animate('#example1', {
      duration: 400,
      property: 'opacity',
    });
  }
  $num = $('.my-card').length;
  $even = $num / 2;
  $odd = ($num + 1) / 2;

  if ($num % 2 == 0) {
    $('.my-card:nth-child(' + $even + ')').addClass('active');
    $('.my-card:nth-child(' + $even + ')')
      .prev()
      .addClass('prev');
    $('.my-card:nth-child(' + $even + ')')
      .next()
      .addClass('next');
  } else {
    $('.my-card:nth-child(' + $odd + ')').addClass('active');
    $('.my-card:nth-child(' + $odd + ')')
      .prev()
      .addClass('prev');
    $('.my-card:nth-child(' + $odd + ')')
      .next()
      .addClass('next');
  }

  $('.my-card').click(function () {
    $slide = $('.active').width();
    console.log($('.active').position().left);

    if ($(this).hasClass('next')) {
      $('.card-carousel')
        .stop(false, true)
        .animate({ left: '-=' + $slide });
    } else if ($(this).hasClass('prev')) {
      $('.card-carousel')
        .stop(false, true)
        .animate({ left: '+=' + $slide });
    }

    $(this).removeClass('prev next');
    $(this).siblings().removeClass('prev active next');

    $(this).addClass('active');
    $(this).prev().addClass('prev');
    $(this).next().addClass('next');
  });

  // Keyboard nav
  $('html body').keydown(function (e) {
    if (e.keyCode == 37) {
      // left
      $('.active').prev().trigger('click');
    } else if (e.keyCode == 39) {
      // right
      $('.active').next().trigger('click');
    }
  });

  $('.prev-icon').click(function () {
    $('.active').prev().trigger('click');
  });
  $('.next-icon').click(function () {
    $('.active').next().trigger('click');
  });

  const hamburger = document.querySelector('.hamburger'),
    navLinks = document.querySelector('.nav-links'),
    links = document.querySelectorAll('.nav-links li');

  hamburger.addEventListener('click', () => {
    //Animate Links
    navLinks.classList.toggle('open');
    if ($('.nav-links').hasClass('open')) {
      $('body,html').css('overflow-y', 'hidden');
      $('body,html').css('height', '100%');
    } else {
      $('body,html').css('overflow-y', 'auto');
      $('body,html').css('height', 'auto');
    }
    links.forEach((link) => {
      link.classList.toggle('fade');
    });

    //Hamburger Animation
    hamburger.classList.toggle('toggle');
  });

  function runTimeLine() {
    var getListItem = $('.timeline-roller').find('ul').data('re-item'),
      itemGap = $('.timeline-roller').find('ul').data('re-gap'),
      yearData = $('.timeline-roller').find('ul').data('years'),
      liArray = [];
    for (let i = 0; i < getListItem; i++) {
      let yearStar = yearData[i].startYear;
      let yearEnd = yearData[i].endYear;
      liArray.push(
        `<li class="pointer-li" data-start-year='${yearStar}' data-end-year='${yearEnd}'>
        <span class='year-class-start'>${yearStar}  <soan class='end-time'> to ${yearEnd}</span>

        </li>`
      );

      if (i !== getListItem - 1) {
        for (let j = 0; j < itemGap; j++) {
          liArray.push('<li class="inner-li"></li>');
        }
      }
    }

    $('.rollerUL').append(liArray);

    let centeryr = $('.rollerUL').data('center-year');
    let viewportOffset = $(
      ".pointer-li[data-start-year='" + centeryr + "']"
    ).offset();
    let getCengerliIntex = $(
      ".pointer-li[data-start-year='" + centeryr + "']"
    ).index();
    $('.pointer-li').find('.end-time').fadeOut();
    $('.pointer-li').click(function () {
      // these are relative to the viewport, i.e. ˜jtnmbhe window
      let getSeletedyr = $(this).data('start-year');
      let getSelLi = $(this).index();
      let viewportOffsetSelected = $(this).offset();
      let leftshift = viewportOffset.left;
      let getHalfWid;
      $('.pointer-li').find('.end-time').fadeOut();
      $('.pointer-li').removeClass('active-time-line');
      $(this).addClass('active-time-line');
      $(this).find('.end-time').fadeIn();
      if ($(window).width() > 768) {
        if (getSelLi < getCengerliIntex) {
          getHalfWid = viewportOffsetSelected.left - leftshift;
          if (viewportOffsetSelected.left > leftshift) {
            $('.rollerUL').css('margin-left', -Math.abs(getHalfWid));
          } else {
            $('.rollerUL').css('margin-left', Math.abs(getHalfWid / 2));
          }
        } else {
          getHalfWid = viewportOffsetSelected.left - leftshift;
          $('.rollerUL').css('margin-left', -Math.abs(getHalfWid / 2));
        }
      }
      $('.imgSlider').find('.slide-item').removeClass('active-slide');
      $('.imgSlider').find('.slide-item').addClass('slide-hidden');
      $('.imgSlider')
        .find(".slide-item[data-start-year='" + getSeletedyr + "']")
        .addClass('active-slide');
      $('.imgSlider')
        .find(".slide-item[data-start-year='" + getSeletedyr + "']")
        .removeClass('slide-hidden');
    });
  }

  runTimeLine();
  $('.rollerUL').find('li').eq(0).trigger('click');
  $('.arrow-icon.re-time-arrow')
    .find('.next-icon')
    .click(function () {
      $('.rollerUL')
        .find('.active-time-line')
        .nextAll('.pointer-li')
        .eq(0)
        .trigger('click');
    });
  $('.arrow-icon.re-time-arrow')
    .find('.prev-icon')
    .click(function () {
      $('.rollerUL')
        .find('.active-time-line')
        .prevAll('.pointer-li')
        .eq(0)
        .trigger('click');
    });
  var headerBottom =
      $('.iwc-header-wrapper') && $('.iwc-header-wrapper').position()
        ? $('.iwc-header-wrapper').position().top +
          $('.iwc-header-wrapper').outerHeight(true)
        : 0,
    headerHeight = $('.iwc-header-wrapper').outerHeight();

  function stickyActive() {
    var windowTop = $(window).scrollTop();

    // Add custom sticky class
    if (windowTop >= headerBottom) {
      $header.addClass(cssClass.stickFullHeader);
    } else {
      $header.removeClass(cssClass.stickFullHeader);
      $header.removeClass(cssClass.stickBottomMenu);
    }

    // Show/hide
    if ($header.hasClass(cssClass.stickFullHeader)) {
      if (windowTop <= headerBottom || windowTop < lastScrollTop) {
        $header.addClass(cssClass.stickBottomMenu);
      } else {
        $header.height(headerHeight);
        $header.removeClass(cssClass.stickBottomMenu);
      }
    }

    lastScrollTop = windowTop;
  }
  $(window).scroll(function () {
    stickyActive();
  });
  // handlescroll animation
});
